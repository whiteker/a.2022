/*
zsh_construction.c
code by zsh
date : 2022/07/13
*/
#include "zsh_construction.h"
using namespace std;
using namespace cv;
/****************************************/
// para
ZSH_CONSTRUCTION zsh_construction_flag = CONSTRUCTION_NULL; //施工区状态初始化
uint8_t ZSH_CONSTRUCTION_SPEED = 170;
/****************************************/
// func extern
uint8_t zsh_construction_null(void);
uint8_t zsh_construction_begin(void);
uint8_t zsh_construction_in(void);
uint8_t zsh_construction_inside(void);
uint8_t zsh_construction_out(void);
uint8_t zsh_construction_reset(void);
/****************************************/

uint8_t zsh_construction_init(void)
{
}

uint8_t zsh_construction_deal(void)
{
    // zsh_construction_flag=CONSTRUCTION_OUT;
    // cout << "zsh_construction_flag:" << zsh_construction_flag << endl;
    // zsh_construction_flag=CONSTRUCTION_INSIDE;
    switch (zsh_construction_flag)
    {
    case CONSTRUCTION_BEGIN:
        zsh_construction_begin();
        break;
    case CONSTRUCTION_IN:
        zsh_construction_in();
        break;
    case CONSTRUCTION_INSIDE:
        zsh_construction_inside();
        break;
    case CONSTRUCTION_OUT:
        zsh_construction_out();
        break;
    case CONSTRUCTION_RESET:
        zsh_construction_reset();
        break;
    default:
        zsh_construction_null();
    }
}

uint8_t zsh_construction_null(void)
{
}

uint8_t zsh_construction_begin(void)
{
    cout << "con begin" << endl;

    if (1)
    {
        usleep(100000);
        zsh_construction_flag = CONSTRUCTION_IN; //跳转到IN
    }
}

uint8_t zsh_construction_in(void)
{
    cout << "con in" << endl;

    zsh_get_red_mask_pixle(red_mask);

    //左
    // zsh_find_right_bottom_pixle();
    // rightline[zshConstructionBeginaAxis_Y] = zshConstructionBeginaAxis_X;
    // rightline[59] = 119;
    // connect(59, zshConstructionBeginaAxis_Y, rightline);
    // for (uint hang = 59; hang > zshConstructionBeginaAxis_Y; hang--)
    // {
    //     leftlineflag[hang] = 0;
    //     rightlineflag[hang] = 1;
    // }
    // if (zshConstructionBeginaAxis_Y > 35 && zshConstructionBeginaAxis_X > 70)
    // {
    //     zsh_construction_flag = CONSTRUCTION_INSIDE;
    // }

    zsh_find_left_bottom_pixle(10);
    leftline[zshConstructionBeginaAxis_Y] = zshConstructionBeginaAxis_X;
    leftline[59] = 0;
    connect(59, zshConstructionBeginaAxis_Y, leftline);
    for (uint hang = 59; hang > zshConstructionBeginaAxis_Y; hang--)
    {
        leftlineflag[hang] = 1;
        rightlineflag[hang] = 0;
    }
    if (zshConstructionBeginaAxis_Y > 35 && zshConstructionBeginaAxis_X < 50)
    {
        zsh_construction_flag = CONSTRUCTION_INSIDE;
    }
}

uint8_t zsh_construction_inside(void)
{
    cout << "con inside" << endl;

    int _temp_1 = 0;
    int _temp_2 = 0;
    for (int j = 0; j < 6; j++)
    {
        for (int i = 30; i < 90; i++) // 90
        {
            if (Pixle[25 + j][i] == black)
            {
                _temp_1++;
            }
        }
    }

    cout << "_temp_1_:" << _temp_1 << endl;
    if (_temp_1 > 200)
    {
        zsh_construction_flag = CONSTRUCTION_OUT;
    }
}

uint8_t zsh_construction_out(void)
{
    cout << "con out" << endl;

    zsh_get_red_mask_pixle(red_mask);

    //左
    // zsh_find_right_bottom_pixle2();
    // leftline[zshConstructionBeginaAxis_Y] = (zshConstructionBeginaAxis_X + 5 > 119) ? 119 : (zshConstructionBeginaAxis_X + 5);
    // leftline[59] = 3;
    // connect(59, zshConstructionBeginaAxis_Y, leftline);
    // for (uint hang = 59; hang > zshConstructionBeginaAxis_Y; hang--)
    // {
    //     leftlineflag[hang] = 1;
    //     rightlineflag[hang] = 0;
    // }
    // if (zshConstructionBeginaAxis_Y > 30 && zshConstructionBeginaAxis_X < 40)
    // {
    //     zsh_construction_flag = CONSTRUCTION_RESET;
    // }

    zsh_find_left_bottom_pixle(5);
    rightline[zshConstructionBeginaAxis_Y] = (zshConstructionBeginaAxis_X - 5 < 0) ? 0 : (zshConstructionBeginaAxis_X - 5);
    rightline[59] = 116;
    connect(59, zshConstructionBeginaAxis_Y, rightline);
    for (uint hang = 59; hang > zshConstructionBeginaAxis_Y; hang--)
    {
        leftlineflag[hang] = 0;
        rightlineflag[hang] = 1;
    }
    if (zshConstructionBeginaAxis_Y > 30 && zshConstructionBeginaAxis_X > 80)
    {
        zsh_construction_flag = CONSTRUCTION_RESET;
    }
}
extern int lqp_flag;
extern int lqp_Foresight;

uint8_t zsh_construction_reset(void)
{
    cout << "con reset" << endl;
    static int con_o_cnt = 0;
    con_o_cnt++;
    if (con_o_cnt <= 30)
    {
    }
    else
    {
        lqp_flag = 0;
        con_o_cnt = 0;
        zsh_construction_flag = CONSTRUCTION_NULL;
    }
}