#include <fstream>
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "Image_process.h"


using namespace std;

extern int sancha_flag;                 
extern uint Pixle[Row][Col];
extern unsigned char SPEED;
extern uint endline;

extern int leftline[Row];
extern int midline[Row];
extern int rightline[Row];

extern uint leftlineflag[Row];
extern uint rightlineflag[Row];

extern fstream myFile;

int sancha_right_flag = 0;
int sancha_left_flag = 0;


void sancha_start();
void sancha_ru();
void sancha_switch();
void sancha_zhong();
void sancha_chu();

void sancha_start_L();
void sancha_ru_L();
void sancha_zhong_L();
void sancha_chu_L();

void sancha_right(){
    switch (sancha_flag)
    {
    case 1:
        sancha_start();
        break;
    case 2:
        sancha_ru();
        break;
    case 3:
        sancha_zhong();
        break;
    case 4:
        sancha_chu();
        break;
    
    default:
        break;
    }
}

void sancha_left(){
    switch (sancha_flag)
    {
    case 1:
        sancha_start_L();
        break;
    case 2:
        sancha_ru_L();
        break;
    case 3:
        sancha_zhong_L();
        break;
    case 4:
        sancha_chu_L();
        break;
    
    default:
        break;
    }
}

void sancha_start(){
    cout<<"三叉开始"<<endl;
    int low_x = 60, low_y = 30;

    for(int lie = 30; lie < 90; lie++){
        for(int hang = 50; hang > 5; hang--){
            if(Pixle[hang][lie] == white && Pixle[hang+1][lie] == white && Pixle[hang-1][lie] == black && Pixle[hang-2][lie] == black){
                if(hang > low_y){
                    low_x = lie;
                    low_y = hang;
                }
            }
        }
    }
    
    endline = low_y;
    leftline[low_y] = low_x;
    leftline[59] = 10;
    connect(59, low_y, leftline);
    for (uint hang = 59; hang > low_y; hang--)
    {
        leftlineflag[hang] = 1;
        rightlineflag[hang] = 0;
    }

    if(low_y > 45){
        sancha_flag = 2;
    }
}

void sancha_ru(){
    for(uint hang=Row-1;hang>endline;hang--)                //直接确定左线和右线
    {
        leftline[hang]=0;                          //20
        rightline[hang] = 119;           
        leftlineflag[hang]=1;
        rightlineflag[hang]=1;
    }
    // uint sancha_white = 0;
    // for(uint hang = 59; hang > 30; hang--){                  //找最右边两列、下30行的白点
    //     for(uint lie = 105; lie>=104 ;lie--){
    //         if(Pixle[hang][lie] == white)   sancha_white++;
    //     }
    // }
    // uint sancha_di_black = 0;
    // for(uint hang = 57; hang >= 55; hang--){                  //找最左边两列、下30行的黑点
    //     for(uint lie = 0; lie<60 ;lie++){
    //         if(Pixle[hang][lie] == black)   sancha_di_black++;
    //     }
    // }

    // uint sancha_black = 0;
    // for(uint hang = 59; hang > 30; hang--){                  //找最左边两列、下30行的黑点
    //     for(uint lie = 40; lie<=41 ;lie++){
    //         if(Pixle[hang][lie] == black)   sancha_black++;
    //     }
    // }
    
    uint ru_hang1 = 56, ru_hang2 = 57;
    int ru_lie1 = 0, ru_lie2 = 0;

    for(uint lie = 0; lie < 110; lie++){
        if(Pixle[ru_hang1][lie] == black && Pixle[ru_hang1][lie+1] == white && Pixle[ru_hang1][lie+2] == white){
            ru_lie1 = lie;
            cout<<"ru_lie1 = "<<ru_lie1<<endl;
        }
        if(Pixle[ru_hang2][lie] == black && Pixle[ru_hang2][lie+1] == white && Pixle[ru_hang2][lie+2] == white){
            ru_lie2 = lie;
            cout<<"ru_lie2 = "<<ru_lie2<<endl;
        }
    }
    
    // cout<< sancha_black <<"  "<< sancha_di_black<<endl;
    // if(sancha_black > 55 && sancha_di_black > 165)

    // cout<<"ru = "<<ru_lie1<<"  "<<ru_lie2<<endl;
    if(ru_lie1 > 60 && ru_lie2 > 60)
    {
        sancha_flag = 3;
        cout<<"进入三叉"<<endl;
    }

}

void sancha_switch(){
    for(int hang = 0; hang<Row - 1; hang++){        //对图片进行黑白转换
        for(int lie = 0; lie<Col - 1; lie++){
            if(Pixle[hang][lie] == black){
                Pixle[hang][lie] = white;
            }
            else{
                Pixle[hang][lie] = black; 
            }
        }
    }
}

void sancha_zhong(){            //三叉中看看什么时候该出去了
    // int you_xielv = regression(endline, Row - 2, rightline);        //计算右线斜率
    // cout<<"右线斜率 == "<< you_xielv<<endl;
    cout<<"截止行 == "<< endline<<endl;

    sancha_right_flag = 1;          //表示三叉里面，走右边，右线补左线

    uint white_hang = 0;    //白行
    uint white_dot = 0;     //白点
    int you_xie_flag = 0;

    for(uint hang = endline - 3; hang > endline - 8; hang--){       //截止行上边的行，左半部分必定是白色的
        for(uint lie = 0; lie<60; lie++){
            if(Pixle[hang][lie] == black){                          //这里做了黑白变换，所以是black
                white_dot++;
            }
        }
        cout<<"白点 == "<<white_dot<<endl;
        if(white_dot > 55){
            white_hang++;
        }
        white_dot = 0;
    }
    cout<<"白行 =="<<white_hang<<endl;

    for(uint hang = 55;hang>50;hang--){                                                     //出三叉的时候右线向内收
        if(rightline[hang]-rightline[hang-1]>1 && rightline[hang-1]-rightline[hang-2]>1)                
            if(rightlineflag[hang]!=0&&rightlineflag[hang-1]!=0&&rightlineflag[hang-2]!=0){
                you_xie_flag = 1;                                                              //用计数器会更好？
                cout<<"出三叉：：右线下方向左倾斜"<<endl;
            }
    }

    if(endline > 36 && white_hang > 1 && you_xie_flag == 1){
        sancha_flag = 4;
        sancha_right_flag = 0;
    }
}

void sancha_chu(){
    for(uint hang=Row-1;hang>endline;hang--)                //直接确定左线和右线
    {
        leftline[hang]=50;                  //35
        rightline[hang] = 119;           
        leftlineflag[hang]=1;
        rightlineflag[hang]=1;
    }

    uint sancha_chu_black = 0;
    for(uint hang = 59; hang > 56; hang--){                  //找最下面5行、中间110列的黑点
        for(uint lie = 15; lie<95 ;lie++){
            if(Pixle[hang][lie] == black)   sancha_chu_black++;
        }
    }
    cout<<"sancha_chu_black == "<<sancha_chu_black<<endl;
    if(sancha_chu_black < 10){       //图像下面几乎不存在黑点，就认为是出了三叉区
        sancha_flag = 0;
    }
}

void sancha_start_L(){
    cout<<"三叉开始"<<endl;
    int low_x = 60, low_y = 30;

    for(int lie = 30; lie < 90; lie++){
        for(int hang = 50; hang > 5; hang--){
            if(Pixle[hang][lie] == white && Pixle[hang+1][lie] == white && Pixle[hang-1][lie] == black && Pixle[hang-2][lie] == black){
                if(hang > low_y){
                    low_x = lie;
                    low_y = hang;
                }
            }
        }
    }
    
    endline = low_y;
    rightline[low_y] = low_x;
    rightline[59] = 110;
    connect(59, low_y, rightline);
    for (uint hang = 59; hang > low_y; hang--)
    {
        leftlineflag[hang] = 0;
        rightlineflag[hang] = 1;
    }

    if(low_y > 45){
        sancha_flag = 2;
    }
}

void sancha_ru_L(){
    for(uint hang=Row-1;hang>endline;hang--)                //直接确定左线和右线
    {
        leftline[hang]=0;                          //20
        rightline[hang] = 119;           
        leftlineflag[hang]=1;
        rightlineflag[hang]=1;
    }
    // uint sancha_white = 0;
    // for(uint hang = 59; hang > 30; hang--){                  //找最右边两列、下30行的白点
    //     for(uint lie = 105; lie>=104 ;lie--){
    //         if(Pixle[hang][lie] == white)   sancha_white++;
    //     }
    // }
    // uint sancha_di_black = 0;
    // for(uint hang = 57; hang >= 55; hang--){                  //找最左边两列、下30行的黑点
    //     for(uint lie = 0; lie<60 ;lie++){
    //         if(Pixle[hang][lie] == black)   sancha_di_black++;
    //     }
    // }

    // uint sancha_black = 0;
    // for(uint hang = 59; hang > 30; hang--){                  //找最左边两列、下30行的黑点
    //     for(uint lie = 40; lie<=41 ;lie++){
    //         if(Pixle[hang][lie] == black)   sancha_black++;
    //     }
    // }
    
    uint ru_hang1 = 56, ru_hang2 = 57;
    int ru_lie1 = 0, ru_lie2 = 0;

    for(uint lie = 119; lie > 10; lie--){
        if(Pixle[ru_hang1][lie] == black && Pixle[ru_hang1][lie-1] == white && Pixle[ru_hang1][lie-2] == white){
            ru_lie1 = lie;
            cout<<"ru_lie1 = "<<ru_lie1<<endl;
        }
        if(Pixle[ru_hang2][lie] == black && Pixle[ru_hang2][lie-1] == white && Pixle[ru_hang2][lie-2] == white){
            ru_lie2 = lie;
            cout<<"ru_lie2 = "<<ru_lie2<<endl;
        }
    }
    
    // cout<< sancha_black <<"  "<< sancha_di_black<<endl;
    // if(sancha_black > 55 && sancha_di_black > 165)

    // cout<<"ru = "<<ru_lie1<<"  "<<ru_lie2<<endl;
    if(ru_lie1 < 60 && ru_lie2 < 60)
    {
        sancha_flag = 3;
        cout<<"进入三叉"<<endl;
    }

}

void sancha_zhong_L(){            //三叉中看看什么时候该出去了
    // int you_xielv = regression(endline, Row - 2, rightline);        //计算右线斜率
    // cout<<"右线斜率 == "<< you_xielv<<endl;
    cout<<"截止行 == "<< endline<<endl;
    sancha_left_flag = 1;

    uint white_hang = 0;    //白行
    uint white_dot = 0;     //白点
    int zuo_xie_flag = 0;

    for(uint hang = endline - 3; hang > endline - 8; hang--){       //截止行上边的行，左半部分必定是白色的
        for(uint lie = 60; lie<=199; lie++){
            if(Pixle[hang][lie] == black){                          //这里做了黑白变换，所以是black
                white_dot++;
            }
        }
        cout<<"白点 == "<<white_dot<<endl;
        if(white_dot > 55){
            white_hang++;
        }
        white_dot = 0;
    }
    cout<<"白行 =="<<white_hang<<endl;

    for(uint hang = 55;hang>50;hang--){                                                     //出三叉的时候右线向内收
        if(leftline[hang]-leftline[hang-1]<-1 && leftline[hang-1]-leftline[hang-2]<-1)                
            if(leftlineflag[hang]!=0&&leftlineflag[hang-1]!=0&&leftlineflag[hang-2]!=0){
                zuo_xie_flag = 1;                                                              //用计数器会更好？
                cout<<"出三叉：：右线下方向左倾斜"<<endl;
            }
    }

    if(endline > 36 && white_hang > 1 && zuo_xie_flag == 1){
        sancha_flag = 4;
        sancha_left_flag = 0;
    }
}

void sancha_chu_L(){
    for(uint hang=Row-1;hang>endline;hang--)                //直接确定左线和右线
    {
        leftline[hang]=0;                  //35
        rightline[hang] = 69;           
        leftlineflag[hang]=1;
        rightlineflag[hang]=1;
    }

    uint sancha_chu_black = 0;
    for(uint hang = 59; hang > 56; hang--){                  //找最下面5行、中间110列的黑点
        for(uint lie = 15; lie<95 ;lie++){
            if(Pixle[hang][lie] == black)   sancha_chu_black++;
        }
    }
    cout<<"sancha_chu_black == "<<sancha_chu_black<<endl;
    if(sancha_chu_black < 10){       //图像下面几乎不存在黑点，就认为是出了三叉区
        sancha_flag = 0;
    }
}