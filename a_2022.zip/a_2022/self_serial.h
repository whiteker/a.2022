#ifndef SELF_SERIAL_H
#define SELF_SERIAL_H

int ser_Init();
void send();

#endif