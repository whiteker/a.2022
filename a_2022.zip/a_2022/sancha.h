#ifndef SANCHA
#define SANCHA


void sancha_right();
void sancha_left();

void sancha_start();
void sancha_ru();
void sancha_switch();
void sancha_zhong();
void sancha_chu();

void sancha_start_L();
void sancha_ru_L();
void sancha_zhong_L();
void sancha_chu_L();


#endif