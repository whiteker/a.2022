#ifndef __lqp_CONSTRUCTION__
#define __lqp_CONSTRUCTION__

#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <unistd.h>
#include <cmath>
#include <time.h>
#include <mutex>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "Image_process.h"
#include "zsh_construction.h"

enum GasStation_State_e
{
    GASSTATION_NULL = 0x00,   //没有识别到,正常行驶
    GASSTATION_BEGIN = 0x01,  //检测到加油站标志，开始准备进入
    GASSTATION_IN = 0x02,     //检测到起始数字，进入入口
    GASSTATION_INSIDE = 0x03, //加油站中行驶
    GASSTATION_OUT_1 = 0x04,  //检测到1 出加油站
    GASSTATION_OUT_2 = 0x05,  //检测到2 出加油站
    GASSTATION_RESET = 0x06,  //释放加油站状态，回归正常行驶
};
void GasStation_State_Judge(void);
void GasStation_Image_Fliter(void);

extern enum GasStation_State_e GasStation_flag;
extern int number_x[3], number_y[3], number_name[4];

extern int lqp_flag;

extern cv::Mat red_mask;
extern int zshConstructionBeginaAxis_X;
extern int zshConstructionBeginaAxis_Y;
extern int leftline[Row];
extern int rightline[Row];
extern int midline[Row];
extern uint leftlineflag[Row];
extern uint rightlineflag[Row];
extern uint Pixle[Row][Col];



/*
一个很神奇的规律
外面两个数字的标准轨迹
x=1.5y-25
里面两个数字的标准轨迹
x=-1.5y+425
*/

// //数字坐标
// int number_position_matrix[4][30] = {
//     {//外1
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0},
//     {0, //外2
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0},
//     {0,//内1
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0},
//     {0,//内2
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0,
//      0}};

#endif