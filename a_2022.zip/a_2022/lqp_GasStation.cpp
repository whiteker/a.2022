/*
lqp_GasStation.c
code by lqp
date : 2022/08/10
*/

#include "lqp_GasStation.h"
using namespace cv;
using namespace std;
 
/****************************************/

void GasStation_Begin(void);
void GasStation_In(void);
void GasStation_Inside(void);
void GasStation_Out_1(void);
void GasStation_Out_2(void);
void GasStation_Reset(void);
void GasStation_Null(void);
void GasStation_Number1_Find(void);

// para
enum GasStation_State_e GasStation_flag = GASSTATION_NULL; //施工区状态初始化
int number_score_1 = 0;
int number_score_2 = 0;
int lqp_Foresight = 0; //坐标差值

int lqpGasStation_X = 0;
int lqpGasStation_Y = 0;

int out2_en = 0;
extern int gas_out_flag;

int gasstation_out_cnt = 0;

std::mutex lqp_mutex; //给图像加锁

void GasStation_State_Judge(void)
{
     //GasStation_flag = GASSTATION_INSIDE; //调试用

    switch (GasStation_flag)
    {
    case GASSTATION_BEGIN:
        GasStation_Begin();
        break;
    case GASSTATION_IN:
        GasStation_In();
        break;
    case GASSTATION_INSIDE:
        GasStation_Inside();
        break;
    case GASSTATION_OUT_1:
        GasStation_Out_1();
        break;
    case GASSTATION_OUT_2:
        GasStation_Out_2();
        break;
    case GASSTATION_RESET:
        GasStation_Reset();
        break;
    default:
        GasStation_Null();
    }
}

#define NEXT_STATE 1

void GasStation_Begin(void)
{
    cout << "gas begin" << endl;
    number_name[3] = 0;
    if (number_name[0] || NEXT_STATE)
    {
        usleep(20000);
        GasStation_flag = GASSTATION_IN;
    }
}

void GasStation_In(void)
{
    cout << "gas in" << endl;
    switch (number_name[0])
    {
    case 1:
        number_score_1++;
        break;
    case 2:
        number_score_2++;
        break;
    default:
        break;
    }

    lqp_flag = 0;

    lqp_Foresight = 0;
    zsh_get_red_mask_pixle(red_mask);
    lqp_find_right_bottom_pixle();
    rightline[zshConstructionBeginaAxis_Y] = zshConstructionBeginaAxis_X;
    rightline[59] = 119;
    connect(59, zshConstructionBeginaAxis_Y, rightline);
    for (uint hang = 59; hang > zshConstructionBeginaAxis_Y; hang--)
    {
        leftlineflag[hang] = 0;
        rightlineflag[hang] = 1;
    }

    if (zshConstructionBeginaAxis_Y > 35 && zshConstructionBeginaAxis_X > 75)
    {
        // in_flag = 0;
        usleep(100000);

         GasStation_flag = GASSTATION_INSIDE;
       // GasStation_flag = GASSTATION_NULL;
        cout << "跳出" << endl;
    }
    // cout << "number_name[0] == " << number_name[0] << endl;
    // cout << "number_name[1] == " << number_name[1] << endl;
    // cout << "number_name[2] == " << number_name[2] << endl;
    // cout << "in_flag == " << in_flag << endl;
    // cout << "lqp_flag == " << lqp_flag << endl;
    // cout << "number_score_1 == " << number_score_1 << endl;
    // cout << "number_score_2 == " << number_score_2 << endl;
    // cout << "x_now == " << number_x[number_name[0]] << "    x_set == " << number_x[number_name[0]] - 1.3 * number_y[number_name[0]] + 25 << endl;
    // cout << "lqp_Foresight == " << lqp_Foresight << endl;
    // cout << "youxia_x == " << zshConstructionBeginaAxis_X << endl;
    // cout << "youxia_y == " << zshConstructionBeginaAxis_Y << endl;
    // cout << "GasStation_flag == " << GasStation_flag << endl;
    // cout << "    " << endl;
}
int gas__flag = 1;
uint8_t lqp_y2x_1[17] = {90, 78, 66, 63, 59, 55, 50, 47, 44, 41, 39, 37, 36, 33, 30, 28, 36};
uint8_t lqp_y2x_2[17] = {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60};
int inside_step = 0;
int first_inside = 1;

void GasStation_Inside(void)
{
    cout << "gas inside" << endl;

    if (first_inside == 1)
    {
        cout << "number_score_1=" << number_score_1 << endl;
        cout << "number_score_2=" << number_score_2 << endl;

        gas__flag = (number_score_1 > number_score_2) ? 1 : 2;

        first_inside = 2;
        lqp_flag = 1;
        if (gas__flag == 1)
        {
            lqp_Foresight = 3;
        }
        else
        {
            lqp_Foresight = 20;
        }
    }
    else if (first_inside == 2)
    {
        first_inside = 0;
        // usleep(100000);
    }

    cout << "gas__flag = " << gas__flag << endl;

    if (gas__flag == 1)
    {
        GasStation_Number1_Find();
        if (lqpGasStation_Y > 28)
        {

            lqp_flag = 1;
            lqp_Foresight = lqpGasStation_X - lqp_y2x_1[lqpGasStation_Y - 29];

            // cout<<"lqpGasStation_X="<<lqpGasStation_X<<" lqpGasStation_Y="<<lqpGasStation_Y<<endl;
            cout << "lqp_Foresight=" << lqp_Foresight << endl;
            if (lqpGasStation_Y > 40)
            {
                GasStation_flag = GASSTATION_OUT_1;
                first_inside = 1;
            }
        }
    }
    else if (gas__flag == 2)
    {
        GasStation_Number1_Find();
        if (inside_step == 0)
        {
            if (lqpGasStation_Y > 28)
            {
                lqp_flag = 1;
                lqp_Foresight = lqpGasStation_X - lqp_y2x_2[lqpGasStation_Y - 29];

                // cout<<"lqpGasStation_X="<<lqpGasStation_X<<" lqpGasStation_Y="<<lqpGasStation_Y<<endl;
                cout << "lqp_Foresight=" << lqp_Foresight << endl;
                if (lqpGasStation_Y > 40)
                {
                    inside_step = 1;
                }
            }
        }
        else if (inside_step == 1)
        {
            lqp_Foresight = 20;
            inside_step = 2;
        }
        else if (inside_step == 2)
        {
            cout << "sleep_2" << endl;
            usleep(500000);
            inside_step = 3;
        }
        else
        {
            // if (lqpGasStation_Y > 28)
            // {
            //     lqp_flag = 1;
            //     lqp_Foresight = lqpGasStation_X - lqp_y2x_1[lqpGasStation_Y - 29];

            //     // cout<<"lqpGasStation_X="<<lqpGasStation_X<<" lqpGasStation_Y="<<lqpGasStation_Y<<endl;
            //     cout << "lqp_Foresight=" << lqp_Foresight << endl;
            //     if (lqpGasStation_Y > 30)
            //     {
            inside_step = 0;
            GasStation_flag = GASSTATION_OUT_1;
            first_inside = 1;
            //     }
            // }
        }
    }
}

void GasStation_Out_1(void)
{
    cout << "gas out" << endl;
    lqp_flag = 0;

    zsh_get_red_mask_pixle(red_mask);
    zsh_find_right_bottom_pixle();
    leftline[zshConstructionBeginaAxis_Y] = (zshConstructionBeginaAxis_X + 5 > 119) ? 119 : (zshConstructionBeginaAxis_X + 5);
    leftline[59] = 3;
    connect(59, zshConstructionBeginaAxis_Y, leftline);
    for (uint hang = 59; hang > zshConstructionBeginaAxis_Y; hang--)
    {
        leftlineflag[hang] = 1;
        rightlineflag[hang] = 0;
    }
    if (zshConstructionBeginaAxis_Y > 35 && zshConstructionBeginaAxis_X < 40)
    {
        GasStation_flag = GASSTATION_RESET;
    }
}

void GasStation_Out_2(void)
{
}

void GasStation_Reset(void)
{
    cout << "gas reset" << endl;
    static int gas_o_cnt = 0;
    gas_o_cnt++;
    if (gas_o_cnt == 1)
    {
        lqp_Foresight = -10;
        lqp_flag = 1;
    }
    else if (gas_o_cnt == 2)
    {
        usleep(400000);
    }
    else
    {
        gas_o_cnt = 0;
        GasStation_flag = GASSTATION_NULL;
    }
}

void GasStation_Null(void)
{
    inside_step = 0;
    first_inside = 1;
    lqp_flag = 0;
    number_score_1 = 0;
    number_score_2 = 0;
    return;
}

void GasStation_Number1_Find(void)
{
    uint8_t find_flag = 0;
    for (int lie = 30; lie < 100; lie++)
    {
        for (int hang = 50; hang > 20; hang--)
        {
            if (Pixle[hang][lie] == black)
            {
                if (Pixle[hang - 1][lie - 1] && !Pixle[hang - 1][lie] && !Pixle[hang - 1][lie + 1] && Pixle[hang][lie - 1] && !Pixle[hang][lie + 1] && Pixle[hang + 1][lie - 1] && Pixle[hang + 1][lie] && Pixle[hang + 1][lie + 1])
                {
                    if (!find_flag)
                    {
                        find_flag = 1;

                        lqpGasStation_X = lie + 8;
                        lqpGasStation_Y = hang - 5;

                        //显示点用
                        zshConstructionBeginaAxis_X = lqpGasStation_X;
                        zshConstructionBeginaAxis_Y = lqpGasStation_Y;

                        cout << "x=" << lqpGasStation_X << " y=" << lqpGasStation_Y << endl;
                        break;
                    }
                }
            }
        }
        if (find_flag)
        {
            break;
        }
    }
    if (!find_flag)
    {
        cout << "没找到数字点" << endl;
    }
}