#ifndef RING_H
#define RING_H

void ring_start(void);
void ring_find(void);
void ring_ru(void);
void ring_chu(void);

#endif